import { initializeApp } from "https://www.gstatic.com/firebasejs/11.8.1/firebase-app.js";
import { getFirestore, doc, getDoc } from "https://www.gstatic.com/firebasejs/11.8.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyDcneigub2eAJjTrfrkiETuLgy5ule8L6s",
  authDomain: "testlik.firebaseapp.com",
  projectId: "testlik",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const urlParams = new URLSearchParams(window.location.search);
const testId = urlParams.get("id");
let qIndex = parseInt(urlParams.get("q")) || 1;

const questionEl = document.getElementById("question");
const optionsEl = document.getElementById("options");
const nextBtn = document.getElementById("nextBtn");

async function loadQuestion() {
  const docRef = doc(db, "testler", testId);
  const docSnap = await getDoc(docRef);

  if (!docSnap.exists()) {
    questionEl.textContent = "Test bulunamadı.";
    return;
  }

  const data = docSnap.data();
  const questions = data.questions;

  if (qIndex > questions.length) {
    window.location.href = "/test-sonuc.html";
    return;
  }

  const q = questions[qIndex - 1];
  questionEl.textContent = q.question;

  optionsEl.innerHTML = "";
  q.options.forEach((opt, i) => {
    const label = document.createElement("label");
    const radio = document.createElement("input");
    radio.type = "radio";
    radio.name = "option";
    radio.value = opt;
    label.appendChild(radio);
    label.appendChild(document.createTextNode(opt));
    optionsEl.appendChild(label);
    optionsEl.appendChild(document.createElement("br"));
  });

  nextBtn.style.display = "inline-block";
}

nextBtn.onclick = () => {
  const selected = document.querySelector("input[name='option']:checked");
  if (!selected) return alert("Lütfen bir seçenek seçin.");
  window.location.href = `test-render.html?id=${testId}&q=${qIndex + 1}`;
};

loadQuestion();